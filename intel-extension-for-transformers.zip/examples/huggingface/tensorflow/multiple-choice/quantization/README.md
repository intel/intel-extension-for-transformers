Step-by-Step
=========

This document describes the step-by-step instructions for reproducing the quantization on models for the multiple choice tasks on the SWAG dataset.

# Prerequisite
## 1. Installation

Make sure you have installed Intel® Extension for Transformers and all the dependencies in the current example:

```shell
pip install intel-extension-for-transformers
pip install -r requirements.txt
```

# Run

## 1. Run Command (Shell)

- Topology:
   - distilbert_swag

- To get the int8 model

```
bash run_tuning.sh  --topology=[topology]
```

- To benchmark the int8 model


```
bash run_benchmark.sh --topology=[topology] --mode=benchmark --int8=true
```
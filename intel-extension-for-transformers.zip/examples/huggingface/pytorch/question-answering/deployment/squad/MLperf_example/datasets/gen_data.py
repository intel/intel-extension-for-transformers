"""
Run BERT on SQuAD 1.1
code reference Google AI research official BERT code
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import json
import math
import os
import random
from typing import Mapping
import tokenization
import six
import tensorflow as tf
import numpy as np
import argparse



F_version_2_with_negative = False
F_do_lower_case = True
F_predict_file = "./dev-v1.1.json"
F_max_seq_length = 384
F_doc_stride = 128
F_max_query_length = 64


class TF_BERTDataSet_v1():
    """
    feature params:
    self.unique_id = unique_id
    self.example_index = example_index
    self.doc_span_index = doc_span_index
    self.tokens = tokens
    self.token_to_orig_map = token_to_orig_map
    self.token_is_max_context = token_is_max_context
    self.input_ids = input_ids #id 6
    self.input_mask = input_mask # id7
    self.segment_ids = segment_ids # id 8
    self.start_position = start_position
    self.end_position = end_position
    self.is_impossible = is_impossible

    """
    def __init__(self, vocab_file, perf_count=None, label=False):
        self.label = label
        tf.compat.v1.logging.info("***** Creating tokenizers... *****") #tf.logging.info
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(vocab_file)
        tf.compat.v1.logging.info("***** Reading examples... *****")
        eval_examples = read_squad_examples(
          input_file=F_predict_file, is_training=False)

        eval_features = []

        def append_feature(feature):
            eval_features.append(feature)

        convert_examples_to_features(
          examples=eval_examples,
          tokenizer=tokenizer,
          max_seq_length= F_max_seq_length,
          doc_stride=F_doc_stride,
          max_query_length=F_max_query_length,
          is_training=False,
          output_fn=append_feature)
        
        # like mxnet BertDataSet
        self.eval_features = eval_features
        self.count = len(self.eval_features)
        self.perf_count = perf_count if perf_count is not None else self.count
        self.gen_cpp_data()

    def gen_cpp_data(self):
        feature_names=['input_ids','input_mask','segment_ids']
        fps=[]
        for feature_name in feature_names:
            fp=open(feature_name+'.txt','w')
            fp.write(str(self.count)+'\n')
            fps.append(fp)

        for eval_feature in self.eval_features:
            for idx,feature_name in enumerate(feature_names):
                data_list=getattr(eval_feature,feature_name)
                fps[idx].write(str(len(data_list))+'\n')
                for data in data_list:
                    fps[idx].write(str(data)+' ')
                fps[idx].write('\n')

        for idx in range(len(fps)):
            fps[idx].close()

    def __getitem__(self, idx):
        eval_feature = self.eval_features[idx]
        input_ids_data = eval_feature.input_ids
        input_mask_data = eval_feature.input_mask
        segment_ids_data = eval_feature.segment_ids
        input_ids_data += [0] * (F_max_seq_length - len(input_ids_data))
        input_mask_data += [0] * (F_max_seq_length - len(input_mask_data))
        segment_ids_data += [0] * (F_max_seq_length - len(segment_ids_data))

        if self.label:
            return (np.array(input_ids_data), np.array(input_mask_data), 
                    np.array(segment_ids_data)), None
        else:
            return np.array(input_ids_data), np.array(input_mask_data), np.array(segment_ids_data)
        

    def __len__(self):
        return len(self.eval_features)

class TF_BERTDataSet_v2():
     def __init__(self, vocab_file, perf_count=None, label=False):
        self.label = label
        tf.compat.v1.logging.info("***** Creating tokenizers... *****") #tf.logging.info
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(vocab_file)
        tf.compat.v1.logging.info("***** Reading examples... *****")
        eval_examples = read_squad_examples(
          input_file=F_predict_file, is_training=False)

        new_eval_examples = {"question": [], "context": [], "id": []}
        for eval_example in eval_examples:
            new_eval_examples["question"].append(eval_example.question_text)
            new_eval_examples["context"].append(" ".join(eval_example.doc_tokens))
            new_eval_examples["id"].append(eval_example.qas_id)

        from datasets import Dataset

        eval_examples = Dataset.from_dict(new_eval_examples)
        question_column_name  = "question"
        context_column_name = "context"
        pad_on_right = True
        pad_to_max_length = True
        column_names = ['id', 'context', 'question']


        def prepare_validation_features(examples):
            examples[question_column_name] = [q.lstrip() for q in examples[question_column_name]]
            tokenized_examples = tokenizer(
                examples[question_column_name if pad_on_right else context_column_name],
                examples[context_column_name if pad_on_right else question_column_name],
                truncation="only_second" if pad_on_right else "only_first",
                max_length=F_max_seq_length,
                stride=F_doc_stride,
                return_overflowing_tokens=True,
                return_offsets_mapping=True,
            )
            # Since one example might give us several features if it has a long context, we need a map from a feature to
            # its corresponding example. This key gives us just that.
            sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")

            # For evaluation, we will need to convert our predictions to substrings of the context, so we keep the
            # corresponding example_id and we will store the offset mappings.
            tokenized_examples["example_id"] = []
            tokenized_examples["token_type_ids"] = []

            for i in range(len(tokenized_examples["input_ids"])):
                # Grab the sequence corresponding to that example (to know what is the context and what is the question).
                sequence_ids = tokenized_examples.sequence_ids(i)
                context_index = 1 if pad_on_right else 0

                # One example can give several spans, this is the index of the example containing this span of text.
                sample_index = sample_mapping[i]
                tokenized_examples["example_id"].append(examples["id"][sample_index])
                tokenized_examples["token_type_ids"].append([0]*len(tokenized_examples["input_ids"][i]))


                # Set to None the offset_mapping that are not part of the context so it's easy to determine if a token
                # position is part of the context or not.
                tokenized_examples["offset_mapping"][i] = [
                    (o if sequence_ids[k] == context_index else None)
                    for k, o in enumerate(tokenized_examples["offset_mapping"][i])
                ]

            return tokenized_examples

        eval_dataset = eval_examples.map(
                prepare_validation_features,
                batched=True,
                num_proc=1,
                remove_columns=column_names,)

        self.eval_features = eval_dataset
        self.count = len(self.eval_features)

        self.gen_cpp_data()

     def gen_cpp_data(self):
        feature_names=['input_ids','input_mask','segment_ids']
        fps=[]
        for feature_name in feature_names:
            fp=open(feature_name+'.txt','w')
            fp.write(str(self.count)+'\n')
            fps.append(fp)

        for eval_feature in self.eval_features:
            for idx,feature_name in enumerate(feature_names):
                if feature_name == "input_mask":
                    feature_name = "attention_mask"
                if feature_name == "segment_ids":
                    feature_name = "token_type_ids"
                data_list = eval_feature[feature_name]
                fps[idx].write(str(len(data_list))+'\n')
                for data in data_list:
                    fps[idx].write(str(data)+' ')
                fps[idx].write('\n')

        for idx in range(len(fps)):
            fps[idx].close()

     def __getitem__(self, idx):
        eval_feature = self.eval_features[idx]
        input_ids_data = eval_feature.input_ids
        input_mask_data = eval_feature.input_mask
        segment_ids_data = eval_feature.segment_ids
        input_ids_data += [0] * (F_max_seq_length - len(input_ids_data))
        input_mask_data += [0] * (F_max_seq_length - len(input_mask_data))
        segment_ids_data += [0] * (F_max_seq_length - len(segment_ids_data))

        if self.label:
            return (np.array(input_ids_data), np.array(input_mask_data),
                    np.array(segment_ids_data)), None
        else:
            return np.array(input_ids_data), np.array(input_mask_data), np.array(segment_ids_data)


     def __len__(self):
        return len(self.eval_features)

### BERTDataset ###
class SquadExample(object):
    """A single training/test example for simple sequence classification.
       For examples without an answer, the start and end position are -1.
    """

    def __init__(self,
              qas_id,
              question_text,
              doc_tokens,
              orig_answer_text=None,
              start_position=None,
              end_position=None,
              is_impossible=False):
        self.qas_id = qas_id # question ans answer text id
        self.question_text = question_text
        self.doc_tokens = doc_tokens
        self.orig_answer_text = orig_answer_text
        self.start_position = start_position
        self.end_position = end_position
        self.is_impossible = is_impossible

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        s = ""
        s += "qas_id: %s" % (tokenization.printable_text(self.qas_id)) # for py2 or py3
        s += ", question_text: %s" % (
          tokenization.printable_text(self.question_text))
        s += ", doc_tokens: [%s]" % (" ".join(self.doc_tokens))
        if self.start_position:
            s += ", start_position: %d" % (self.start_position)
        if self.start_position:
            s += ", end_position: %d" % (self.end_position)
        if self.start_position:
            s += ", is_impossible: %r" % (self.is_impossible)
        return s


class InputFeatures(object):
    """A single set of features of data."""

    def __init__(self,
              unique_id,
              example_index,
              doc_span_index,
              tokens,
              token_to_orig_map,
              token_is_max_context,
              input_ids,
              input_mask,
              segment_ids,
              start_position=None,
              end_position=None,
              is_impossible=None): 
        self.unique_id = unique_id
        self.example_index = example_index
        self.doc_span_index = doc_span_index
        self.tokens = tokens
        self.token_to_orig_map = token_to_orig_map
        self.token_is_max_context = token_is_max_context
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.segment_ids = segment_ids
        self.start_position = start_position
        self.end_position = end_position
        self.is_impossible = is_impossible # just use squadv1.1


def read_squad_examples(input_file, is_training=False):
    """Read a SQuAD json file into a list of SquadExample."""
    with tf.io.gfile.GFile(input_file, "r") as reader: # tf.gfile.Open()
        input_data = json.load(reader)["data"]

    def is_whitespace(c):
        if c == " " or c == "\t" or c == "\r" or c == "\n" or ord(c) == 0x202F:
            return True
        return False

    examples = []
    for entry in input_data:
        for paragraph in entry["paragraphs"]:
            paragraph_text = paragraph["context"]
            doc_tokens = []
            char_to_word_offset = []
            prev_is_whitespace = True
            for c in paragraph_text:
                if is_whitespace(c):
                    prev_is_whitespace = True
                else:
                    if prev_is_whitespace:
                        doc_tokens.append(c)
                    else:
                        doc_tokens[-1] += c
                    prev_is_whitespace = False
                char_to_word_offset.append(len(doc_tokens) - 1)

            for qa in paragraph["qas"]:
                qas_id = qa["id"]
                question_text = qa["question"]
                start_position = None
                end_position = None
                orig_answer_text = None
                is_impossible = False
                if is_training:
                    if F_version_2_with_negative:
                        is_impossible = qa["is_impossible"]
                    if (len(qa["answers"]) != 1) and (not is_impossible):
                        raise ValueError(
                          "For training, each question should have exactly 1 answer.")
                    if not is_impossible:
                        answer = qa["answers"][0]
                        orig_answer_text = answer["text"]
                        answer_offset = answer["answer_start"]
                        answer_length = len(orig_answer_text)
                        start_position = char_to_word_offset[answer_offset]
                        end_position = char_to_word_offset[answer_offset + answer_length -
                                               1]
                        # Only add answers where the text can be exactly recovered from the
                        # document. If this CAN'T happen it's likely due to weird Unicode
                        # stuff so we will just skip the example.
                        # Note that this means for training mode, every example is NOT
                        # guaranteed to be preserved.
                        actual_text = " ".join(
                          doc_tokens[start_position:(end_position + 1)])
                        cleaned_answer_text = " ".join(
                          tokenization.whitespace_tokenize(orig_answer_text))
                        if actual_text.find(cleaned_answer_text) == -1:
                            tf.logging.warning("Could not find answer: '%s' vs. '%s'",
                                 actual_text, cleaned_answer_text)
                            continue
                    else:
                        start_position = -1
                        end_position = -1
                        orig_answer_text = ""

                example = SquadExample(
                    qas_id=qas_id,
                    question_text=question_text,
                    doc_tokens=doc_tokens,
                    orig_answer_text=orig_answer_text,
                    start_position=start_position,
                    end_position=end_position,
                    is_impossible=is_impossible)
                examples.append(example)

    return examples #get raw example/feature, not performing embedding


def convert_examples_to_features(examples, tokenizer, max_seq_length,
                                 doc_stride, max_query_length, is_training,
                                 output_fn):
    """Loads a data file into a list of `InputBatch`s."""

    unique_id = 1000000000

    for (example_index, example) in enumerate(examples):
        query_tokens = tokenizer.tokenize(example.question_text) 

        if len(query_tokens) > max_query_length:
            query_tokens = query_tokens[0:max_query_length]

        tok_to_orig_index = []
        orig_to_tok_index = []
        all_doc_tokens = []
        for (i, token) in enumerate(example.doc_tokens):
            orig_to_tok_index.append(len(all_doc_tokens))
            sub_tokens = tokenizer.tokenize(token)
            for sub_token in sub_tokens:
                tok_to_orig_index.append(i)
                all_doc_tokens.append(sub_token)

        tok_start_position = None
        tok_end_position = None
        if is_training and example.is_impossible:
            tok_start_position = -1
            tok_end_position = -1
        if is_training and not example.is_impossible:
            tok_start_position = orig_to_tok_index[example.start_position]
            if example.end_position < len(example.doc_tokens) - 1:
                tok_end_position = orig_to_tok_index[example.end_position + 1] - 1
            else:
                tok_end_position = len(all_doc_tokens) - 1
      
            (tok_start_position, tok_end_position) = _improve_answer_span(
                all_doc_tokens, tok_start_position, tok_end_position, tokenizer,
                example.orig_answer_text)

        max_tokens_for_doc = max_seq_length - len(query_tokens) - 3

        # We can have documents that are longer than the maximum sequence length.
        # To deal with this we do a sliding window approach, where we take chunks
        # of the up to our max length with a stride of `doc_stride`.
        _DocSpan = collections.namedtuple(  # pylint: disable=invalid-name
            "DocSpan", ["start", "length"])
        doc_spans = []
        start_offset = 0
        while start_offset < len(all_doc_tokens):
            length = len(all_doc_tokens) - start_offset
            if length > max_tokens_for_doc:
                length = max_tokens_for_doc
            doc_spans.append(_DocSpan(start=start_offset, length=length))
            if start_offset + length == len(all_doc_tokens):
                break
            start_offset += min(length, doc_stride)
    
        for (doc_span_index, doc_span) in enumerate(doc_spans):
            tokens = []
            token_to_orig_map = {}
            token_is_max_context = {}
            segment_ids = []
            tokens.append("[CLS]")
            segment_ids.append(0)
            for token in query_tokens:
                tokens.append(token)
                segment_ids.append(0)
            tokens.append("[SEP]")
            segment_ids.append(0)

            for i in range(doc_span.length):
                split_token_index = doc_span.start + i
                token_to_orig_map[len(tokens)] = tok_to_orig_index[split_token_index]

                is_max_context = _check_is_max_context(doc_spans, doc_span_index,
                                split_token_index)
                token_is_max_context[len(tokens)] = is_max_context
                tokens.append(all_doc_tokens[split_token_index])
                segment_ids.append(1)
            tokens.append("[SEP]")
            segment_ids.append(1)

            input_ids = tokenizer.convert_tokens_to_ids(tokens)

            # The mask has 1 for real tokens and 0 for padding tokens. Only real
            # tokens are attended to.
            input_mask = [1] * len(input_ids)
            
            # when use dynamic seq_len, don't need padding
            # Zero-pad up to the sequence length.
            # while len(input_ids) < max_seq_length:
            #     input_ids.append(0)
            #     input_mask.append(0)
            #     segment_ids.append(0)

            # assert len(input_ids) == max_seq_length
            # assert len(input_mask) == max_seq_length
            # assert len(segment_ids) == max_seq_length

            start_position = None
            end_position = None
            # only need predict here
            if is_training and not example.is_impossible:
            # For training, if our document chunk does not contain an annotation
            # we throw it out, since there is nothing to predict.
                doc_start = doc_span.start
                doc_end = doc_span.start + doc_span.length - 1
                out_of_span = False
                if not (tok_start_position >= doc_start and
                    tok_end_position <= doc_end):
                    out_of_span = True
                if out_of_span:
                    start_position = 0
                    end_position = 0
                else:
                    doc_offset = len(query_tokens) + 2
                    start_position = tok_start_position - doc_start + doc_offset
                    end_position = tok_end_position - doc_start + doc_offset

            if is_training and example.is_impossible:
                start_position = 0
                end_position = 0

                if is_training and example.is_impossible:
                    tf.logging.info("impossible example")
                if is_training and not example.is_impossible:
                    answer_text = " ".join(tokens[start_position:(end_position + 1)])
                    tf.logging.info("start_position: %d" % (start_position))
                    tf.logging.info("end_position: %d" % (end_position))
                    tf.logging.info(
                        "answer: %s" % (tokenization.printable_text(answer_text)))

            feature = InputFeatures(
                unique_id=unique_id,
                example_index=example_index,
                doc_span_index=doc_span_index,
                tokens=tokens,
                token_to_orig_map=token_to_orig_map,
                token_is_max_context=token_is_max_context,
                input_ids=input_ids, #needed
                input_mask=input_mask,  #needed
                segment_ids=segment_ids, #needed
                start_position=start_position,
                end_position=end_position,
                is_impossible=example.is_impossible)

            # Run callback
            output_fn(feature)

            unique_id += 1

def _improve_answer_span(doc_tokens, input_start, input_end, tokenizer,
                         orig_answer_text):
    """Returns tokenized answer spans that better match the annotated answer."""

    # The SQuAD annotations are character based. We first project them to
    # whitespace-tokenized words. But then after WordPiece tokenization, we can
    # often find a "better match". For example:
    #
    #   Question: What year was John Smith born?
    #   Context: The leader was John Smith (1895-1943).
    #   Answer: 1895
    #
    # The original whitespace-tokenized answer will be "(1895-1943).". However
    # after tokenization, our tokens will be "( 1895 - 1943 ) .". So we can match
    # the exact answer, 1895.
    #
    # However, this is not always possible. Consider the following:
    #
    #   Question: What country is the top exporter of electornics?
    #   Context: The Japanese electronics industry is the lagest in the world.
    #   Answer: Japan
    #
    #  In this case, the annotator chose "Japan" as a character sub-span of
    # the word "Japanese". Since our WordPiece tokenizer does not split
    # "Japanese", we just use "Japanese" as the annotation. This is fairly rare
    # in SQuAD, but does happen.
    tok_answer_text = " ".join(tokenizer.tokenize(orig_answer_text))

    for new_start in range(input_start, input_end + 1):
        for new_end in range(input_end, new_start - 1, -1):
            text_span = " ".join(doc_tokens[new_start:(new_end + 1)])
            if text_span == tok_answer_text:
                return (new_start, new_end)

    return (input_start, input_end)

# TODO need to understance later
def _check_is_max_context(doc_spans, cur_span_index, position):
    """Check if this is the 'max context' doc span for the token."""

    # Because of the sliding window approach taken to scoring documents, a single
    # token can appear in multiple documents. E.g.
    #  Doc: the man went to the store and bought a gallon of milk
    #  Span A: the man went to the
    #  Span B: to the store and bought
    #  Span C: and bought a gallon of
    #  ...
    #
    # Now the word 'bought' will have two scores from spans B and C. We only
    # want to consider the score with "maximum context", which we define as
    # the *minimum* of its left and right context (the *sum* of left and
    # right context will always be the same, of course).
    #
    # In the example the maximum context for 'bought' would be span C since
    # it has 1 left context and 3 right context, while span B has 4 left context
    # and 0 right context.
    best_score = None
    best_span_index = None
    for (span_index, doc_span) in enumerate(doc_spans):
        end = doc_span.start + doc_span.length - 1
        if position < doc_span.start:
            continue
        if position > end:
            continue
        num_left_context = position - doc_span.start
        num_right_context = end - position
        score = min(num_left_context, num_right_context) + 0.01 * doc_span.length
        if best_score is None or score > best_score:
            best_score = score
            best_span_index = span_index

    return cur_span_index == best_span_index


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Generate data based on model name")
    parser.add_argument("--model_name", type=str, help="Model name for data")
    args = parser.parse_args()
    if args.model_name is None:
        print("Please supply a model name")
    else:
        if args.model_name == "Minilm_l12" :
            data_set = TF_BERTDataSet_v1("bert-large-uncased-whole-word-masking-finetuned-squad", perf_count=None, label=False)
        elif args.model_name == "Minilm_l8" :
            data_set = TF_BERTDataSet_v2("roberta-base", perf_count=None, label=False)


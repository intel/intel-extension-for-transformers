# Huggingface Examples

Welcome to ONNX Runtime Huggingface examples. The models are from [Huggingface](https://huggingface.co) and model compressor technology is dependent on [Intel® Neural Compressor](https://github.com/intel/neural-compressor). 

## Quantization approach

| Task | PostTrainingDynamic | PostTrainingStatic
|---|:---:|:---:|
|**`speech-recognition`**| ✅ | ✅ |

